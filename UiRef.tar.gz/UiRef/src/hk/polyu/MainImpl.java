package hk.polyu;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;

import hk.polyu.parser.LayoutIdParser;
import hk.polyu.parser.ManifestParser;
import hk.polyu.soot.MainActivityCreator;
import hk.polyu.soot.Repackage;
import hk.polyu.soot.SootEnvironment;
import hk.polyu.util.ADBAutomator;
import hk.polyu.util.ApkSigner;
import hk.polyu.util.IgnoreProcessedApks;

public class MainImpl {
	
	// public static String apkPath = "/home/zhouhao/FAN/HIPAA/effectAPP/ae.gov.dha.dhamedicallibrary.apk";
	// public static String apkRootDirectoryPath = "/home/zhouhao/Downloads/com.sattva.sattvamanager_data/";
	// public static String apkRootDirectoryPath = "/home/zhouhao/FAN/HIPAA/effectAPP/";
	// public static String apkRootDirectoryPath = "/home/zhouhao/FAN/HIPAA/1194mHealth/";
	// public static String apkRootDirectoryPath = "/home/zhouhao/Android_Apk_Sample/UI_interfact_740app/";
	// public static String apkRootDirectoryPath = "/home/zhouhao/data/apk_samples/apkfortest";
	// public static String apkRootDirectoryPath = "/home/zhouhao/data/apk_samples/fdroid_apks";
	public static String apkRootDirectoryPath = "/home/zhouhao/data/gui_app/new250Apk";
	
	public static String apkPath = null;
	
	public static String successProcessedFile = "success.txt";
	public static String errorProcessedFile = "error.txt";
	
	public static void main(String[] args) {
		
		File apkRootDirectory = new File(apkRootDirectoryPath);
		if (!apkRootDirectory.exists()) {
			System.out.println("invalid apkRootDirectoryPath");
			System.exit(0);
		}
		
		HashSet<String> processedApks = IgnoreProcessedApks.calcProcessedApkFile();
		// IgnoreProcessedApks.showProcessedApks(processedApks);
		// System.exit(0);
		
		File[] apkFiles = apkRootDirectory.listFiles();
		for (File apkFile : apkFiles) {
			
			System.gc();
			
			if (!apkFile.getName().endsWith(".apk"))
				continue;
			
			if (processedApks.contains(apkFile.getName().replace(".apk", ""))) {
				continue;
			}
			
			try {
				Thread.sleep(3000);
			} catch (InterruptedException ie) {
				ie.printStackTrace();
			}
			
			/*
			if (!apkFile.getName().equals("ru.adhocapp.gymguide.apk"))
				continue;
			*/
				
			ADBAutomator automator = null;
			boolean execFlag = false;
			boolean execActivityFlag = false; // 两个标志位来确定是谁引发了异常
			
			try {
				
				apkPath = apkFile.getCanonicalPath();
				System.out.println(apkPath);
				
				LayoutIdParser.reset();
				
				ManifestParser manifestParser = new ManifestParser();
				manifestParser.exec();
			
				Repackage repackage = new Repackage();
				repackage.exec();
			
				SootEnvironment.instance().initSoot();
			
				LayoutIdParser idParser = new LayoutIdParser();
				idParser.exec();
			
				MainActivityCreator mainActivityCreator = new MainActivityCreator();
				mainActivityCreator.exec();
			
				SootEnvironment.instance().saveApk();
			
				ApkSigner signer = new ApkSigner();
				signer.exec();
			
				automator = new ADBAutomator();
				
				execFlag = true;
				execActivityFlag = false;
				automator.exec();
				execFlag = false;
				
				execActivityFlag = true;
				automator.execActivity();
				execActivityFlag = false;
				
				automator.clearApk();
				
				writeToFile(successProcessedFile, apkPath);
			} catch (Exception e) {
				
				if (e.getMessage().contains("INSTALL_FAILED"))
					continue;
				
				writeToFile(errorProcessedFile, apkPath + "\n" + e.getMessage() + "\n");
				e.printStackTrace();
				
				if (automator != null) {
					try {
						if (execFlag) {
							automator.execAfterException();
							automator.execAfterExceptionActivity();
						}
						if (execActivityFlag) {
							automator.execAfterExceptionActivity();
						}
						
						automator.clearApk();
					} catch(Exception error) {
						error.printStackTrace();
					}
				}
			}
			
			System.gc();
			
		}
		
	}
	
	private static void writeToFile(String filePath, String content) {
		try {
			File file = new File(filePath);
			if (!file.exists()) {
				file.createNewFile();
			}
			
			FileWriter fw = new FileWriter(file, true);
			fw.write(content + "\n");
			fw.flush();
			fw.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
}