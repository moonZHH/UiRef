package hk.polyu.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.ArrayList;

public class BashRunner {

	private final ArrayList<String> bashCommands;
	private final boolean async;
	
	public BashRunner(ArrayList<String> bashCommands, boolean async) {
		this.bashCommands = bashCommands;
		this.async = async;
	}
	
	public String run() throws IOException, InterruptedException {
		ProcessBuilder builder = new ProcessBuilder(this.bashCommands);
		builder.redirectOutput(Redirect.PIPE);
		builder.redirectError(Redirect.PIPE);
		builder.redirectErrorStream();
		Process process = builder.start();
		// wait for thread if not asynchronous
		if (!async)
			process.waitFor();
		
		byte[] buffer = new byte[4096 * 1024];
		int bufferLength;
		String pipeContent = "";
		BufferedInputStream bis = new BufferedInputStream(process.getInputStream());
		while((bufferLength = bis.read(buffer)) > 0) {
			pipeContent += new String(buffer);
		}
		
		return pipeContent;
	}
	
}
