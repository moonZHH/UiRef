package hk.polyu.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import android.view.KeyEvent;

public class UiTraversal {
	
	public static int currentLayoutIndex = -1;
    public static int totalLayoutNumber = 0;
    public static ArrayList<Integer> layoutIdList = new ArrayList<Integer>();

    public static void init(Activity activity) {
        try {
        	Field classField = activity.getClass().getDeclaredField("layoutIds");
            classField.setAccessible(true);//设置该成员变量为可访问  
            String layoutIds = (String) classField.get(null);
            
            /*
            Class<?> RLayoutClass = Class.forName(activity.getPackageName() + ".R$layout");
            for (Field layoutField : RLayoutClass.getFields()) {
                layoutField.setAccessible(true);
                Object fieldValue = layoutField.get(null);
                if (fieldValue instanceof Integer) {
                    layoutIdList.add((Integer) fieldValue);
                }
            }
            */
            
            int idSize = layoutIds.split(", ").length;
            layoutIdList = new ArrayList<Integer>();
            for (int index = 0; index < idSize; index++) {
            	layoutIdList.add(Integer.parseInt(layoutIds.split(", ")[index]));
            }
            totalLayoutNumber = layoutIdList.size();
            Log.d("polyu_totalNumber", totalLayoutNumber + "");
        } /*catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } */catch (NoSuchFieldException nsfe) {
        	nsfe.printStackTrace();
        } catch (IllegalAccessException exception) {
            exception.printStackTrace();
        }
    }

    public static void traverseLayout(Activity activity, int keyCode) {
    	try {
    		SharedPreferences sp = activity.getSharedPreferences("layout_id", Context.MODE_PRIVATE);
			String ids = "";
			if (sp != null) {
				ids = sp.getString("ids", "");
				if (ids.equals("")) {
					currentLayoutIndex = -1;
				} else {
					currentLayoutIndex = ids.split(", ").length - 1;
				}
			}
			
    		if (keyCode == KeyEvent.KEYCODE_FORWARD && currentLayoutIndex < totalLayoutNumber - 1) {
    			currentLayoutIndex++;
    			Log.d("polyu", Integer.toString(layoutIdList.get(currentLayoutIndex)));
    			
    			String idsOrigin = "";
    			if (sp != null) {
    				idsOrigin = sp.getString("ids", "");
    			}
    			
    			Log.d("polyu_idsOrigin", idsOrigin);
    			
    			String idsAfter = "";
    			if (idsOrigin.equals(""))
    				idsAfter = Integer.toString(layoutIdList.get(currentLayoutIndex)) + ", ";
    			else
    				idsAfter = idsOrigin + Integer.toString(layoutIdList.get(currentLayoutIndex)) + ", ";
    			Editor editor = sp.edit();
    			editor.putString("ids", idsAfter);
    			editor.commit();
    			
    			Log.d("polyu_idsAfter", idsAfter);
    			
    			HashSet<Integer> idsSet = new HashSet<Integer>();
    			if (idsOrigin != "") {
    				int idsSize = idsOrigin.split(", ").length;
    				for (int i = 0; i < idsSize; i++) {
    					idsSet.add(Integer.parseInt(idsOrigin.split(", ")[i]));
    				}
    			}
    			
    			if (!idsSet.contains(layoutIdList.get(currentLayoutIndex))) {
    				Log.d("polyu_setContentView", layoutIdList.get(currentLayoutIndex) + "");
    				activity.setContentView(layoutIdList.get(currentLayoutIndex));
    				Log.d("polyu_resourceName", activity.getResources().getResourceName(layoutIdList.get(currentLayoutIndex)));
    			}
    		}
    	} catch (RuntimeException re) {
    		re.printStackTrace();
    	} catch (Exception ioe) {
    		ioe.printStackTrace();
    	}
    }

    /*
    public static String collectViewInfo(View view) {
        CharSequence textContent = ""; // text
        if (view instanceof  TextView) {
            textContent = ((TextView) view).getText();
            if (textContent == "" || textContent == null) {
                textContent = ((TextView) view).getHint();
                if (textContent == null) {
                    textContent = "";
                }
            }
        }
        String resourceId = view.getId() != -1 ? view.getResources().getResourceName(view.getId()) : ""; // resource-id
        String className = view.getClass().getName(); // class
        String packageName = view.getContext().getPackageName(); // package
        CharSequence descContent = view.getContentDescription(); // content-desc
        String checkable = view instanceof Checkable ? "true" : "false"; // checkable
        String checked = view instanceof Checkable ? (((Checkable) view).isChecked() ? "true" : "false") : "false"; // checked
        String clickable = view.isClickable() ? "true" : "false"; // clickable
        String enabled = view.isEnabled() ? "true" : "false"; // enabled
        String focusable = view.isFocusable() ? "true" : "false"; // focusable
        String focused = view.isFocused() ? "true" : "false"; // focused
        String scrollable = view.isScrollContainer() ? "true" : "false"; // scrollable
        String longClickable = view.isLongClickable() ? "true" : "false"; // long-clickable
        String password = ""; // password
        String selected = view.isSelected() ? "true" : "false"; // selected
        // bounds
        Float x = view.getX();
        Float y = view.getY();
        Rect viewRect = new Rect();
        view.getDrawingRect(viewRect);
        assert viewRect != null;
        int right = viewRect.right;
        int bottom = viewRect.bottom;

        return  "text=" + "\"" + textContent + "\"" + " " +
                "resource-id=" + "\"" + resourceId + "\"" + " " +
                "class=" + "\"" + className + "\"" + " " +
                "package=" + "\"" + packageName + "\"" + " " +
                "content-desc=" + "\"" + descContent + "\"" + " " +
                "checkable=" + "\"" + checkable + "\"" + " " +
                "checked=" + "\"" + checked + "\"" + " " +
                "clickable=" + "\"" + clickable + "\"" + " " +
                "enabled=" + "\"" + enabled + "\"" + " " +
                "focusable=" + "\"" + focusable + "\"" + " " +
                "focused=" + "\"" + focused + "\"" + " " +
                "scrollable=" + "\"" + scrollable + "\"" + " " +
                "long-clickable=" + "\"" + longClickable + "\"" + " " +
                "password=" + "\"" + password + "\"" + " " +
                "selected=" + "\"" + selected + "\"" + " " +
                "bounds=" + "[" + x + "," + y + "]" + "[" + (x + right) + "," + (y + bottom) + "]" + " " +
                "\n";
    }
    */
    
}
